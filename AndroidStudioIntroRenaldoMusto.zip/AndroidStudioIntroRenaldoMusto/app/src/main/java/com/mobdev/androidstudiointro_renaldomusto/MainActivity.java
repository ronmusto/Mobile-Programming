package com.mobdev.androidstudiointro_renaldomusto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText mNameText;
    private TextView mGreetingText;
    private Button mButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNameText = findViewById(R.id.nameText);
        mGreetingText = findViewById(R.id.textGreeting);
        mButton = findViewById(R.id.buttonSayHello);
        mButton.setEnabled(true);
    }


    public void SayHello(View view) {

        String userInput;
        userInput = mNameText.getText().toString();


        if(userInput != "") {
            mGreetingText.setText("Hello " + userInput);
        }

        if(userInput.equals("")) {
            mButton.setEnabled(false);
        }

        if(userInput.equals("")){
            mGreetingText.setText("You must enter a name");
        }
    }
}